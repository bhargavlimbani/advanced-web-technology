// Q1: Import required modules
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet'); // Q7
const rateLimit = require('express-rate-limit'); // Q7
const fs = require('fs');

const app = express();

// Que -1
app.use(express.json());
app.use(cors());

// Question 7: 
app.use(helmet());
const limiter = rateLimit({ windowMs: 60000, max: 10 });
app.use(limiter);

// Q1: Static file (for uploads)
app.use(express.static('uploads'));

// Q3: Logger middleware
app.use((req, res, next) => {
  console.log(req.method, req.url);
  next();
});

// Q1: Create JSON files if not exist
if (!fs.existsSync('./data/tasks.json')) {
  fs.writeFileSync('./data/tasks.json', '[]');
}
if (!fs.existsSync('./data/users.json')) {
  fs.writeFileSync('./data/users.json', '[]');
}

// app.use('/api/tasks', require('./routes/taskRouter')); // q-2
app.use('/api/auth', require('./routes/AuthRouter')); // q-4

// Q3: Error handler
app.use((err, req, res, next) => {
  res.status(500).json({ error: err.message });
});

// Q8: Port.env
const PORT = process.env.PORT || 5000;

// Start server
app.listen(PORT, () => {
  console.log("Server running on port " + PORT);
});