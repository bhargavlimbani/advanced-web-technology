// Import modules
const express = require('express');
const fs = require('fs');
const router = express.Router();

// File path
const FILE = './tasks.json';

//quetion - 5 search
router.get('/search/filter', (req, res) => {
  let tasks = readTasks();

  res.json(tasks);
});

module.exports = router;