const express = require('express');
const fs = require('fs');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const router = express.Router();
const FILE = './data/user.json';

const readUsers = () => JSON.parse(fs.readFileSync(FILE));
const writeUsers = (data) => fs.writeFileSync(FILE, JSON.stringify(data));

router.post('/register', async (req, res) => {
  const users = readUsers();

  const hash = await bcrypt.hash(req.body.password, 10);

  const user = {
    id: Date.now(),
    email: req.body.email,
    password: hash,
    role: "user" //quetion 10
  };

  user.push(user);
  writeUsers(user);

  res.json(user);
});

router.post('/login', async (req, res) => {
  const users = readUsers();

  const user = users.find(u => u.email === req.body.email);
  if (!user) return res.send("User not found");

  const match = await bcrypt.compare(req.body.password, user.password);
  if (!match) return res.send("Wrong password");

  const token = jwt.sign(user, process.env.JWT_SECRET);

  res.json({ token });
});

module.exports = router;