import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

const Register = () => {
    const { register } = useAuth();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [errorMessage, setErrorMessage] = useState('');
    const [msg, setMsg] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

        const res = register(email, password);
        setMsg(res);
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Register</h2>
            
            <input placeholder="Email" onChange={e => setEmail(e.target.value)} />
            <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter Password"
                value={password}
                onChange={(e) => {
                    setPassword(e.target.value);
                    setErrorMessage("");
                }}

            />
            <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}

            >
                {showPassword ? "Hide" : "Show"}
            </button>


            <button>Register</button>

            {msg && <p>{msg}</p>}
        </form>
    );
};

export default Register;