import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const Login = () => {
    const { login } = useAuth();
    const navigate = useNavigate();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();

        if (!email || !password) {
            setError("All fields required");
            return;
        }

        const success = login(email, password);

        if (success) navigate("/tasks");
        else setError("please login again");
    };

    return (
        <form onSubmit={handleSubmit}>
            <h2>Login</h2>

            <input placeholder="Email" onChange={e => setEmail(e.target.value)} />
            <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter Password"
                value={password}
                onChange={(e) => {
                    setPassword(e.target.value);
                    setErrorMessage("");
                }}

            />
            <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}

            >
                {showPassword ? "Hide" : "Show"}
            </button>

            <button>Login</button>
            {error && <p>{error}</p>}
        </form>
    );
};

export default Login;