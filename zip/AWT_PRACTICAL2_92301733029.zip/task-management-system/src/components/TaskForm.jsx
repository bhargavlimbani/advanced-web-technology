import { useState } from "react";
import { useTasks } from "../contexts/TaskContext";
import { useNavigate } from "react-router-dom";

const TaskForm = () => {

  const { addTask } = useTasks();
  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!title) {
      setError("Title is required");
      return;
    }

    addTask({ title });
    navigate("/tasks");
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Add Task</h2>

      <input
        placeholder="Enter task"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      <button>Add</button>

      {error && <p>{error}</p>}
    </form>
  );
};

export default TaskForm;