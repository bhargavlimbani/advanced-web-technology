import { useState } from 'react';
import { useTasks } from '../contexts/TaskContext';
import { Link } from 'react-router-dom';

const TaskList = () => {

  const { tasks, deleteTask } = useTasks();
  const [search, setSearch] = useState('');

  const filtered = tasks.filter(t =>
    t.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <h2>Tasks</h2>

      <input
        placeholder="Search"
        onChange={e => setSearch(e.target.value)}
      />

      <Link to="/tasks/new">Add Task</Link>

      {filtered.map(task => (
        <div key={task.id}>
          <h4>{task.title}</h4>

          <Link to={`/task/${btoa(task.id)}`}>View</Link>
          <button onClick={() => deleteTask(task.id)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default TaskList;